/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/SessionRemote.java to edit this template
 */
package ec.edu.monster.controlador;

import javax.ejb.Remote;

/**
 *
 * @author Andrés
 */
@Remote
public interface EJBTimersDemoRemote {
    
}
