﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Grupo01_Sincronizacion_MVC.Modelo
{
    internal class ModeloHilo1
    {
        public static Thread hilo1;
    }
}
