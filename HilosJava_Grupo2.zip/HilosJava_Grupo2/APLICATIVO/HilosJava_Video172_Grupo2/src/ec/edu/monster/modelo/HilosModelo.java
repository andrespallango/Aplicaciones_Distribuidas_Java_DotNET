
package ec.edu.monster.modelo;

/**
 *
 * @author Mosquera - Pallango - Sánchez
 */
public class HilosModelo {
    public Thread hilo1;
}
