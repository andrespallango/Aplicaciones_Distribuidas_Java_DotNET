package ec.edu.monster.vista;

/**
 *
 * @author Mosquera - Pallango - Sánchez
 */
public class HilosVista {
    public void imprimirInfoHilo(String nombreHilo) {
        System.out.println("Ejecutando hilo..." + nombreHilo);
    }
    
    
    public void imprimirFinalizado() {
        System.out.println("Terminadas las tareas...");
    }
}
