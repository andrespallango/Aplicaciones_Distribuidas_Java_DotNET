/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.monster.main;

import javax.swing.JFrame;
import  ec.edu.monster.vista.Vista;

/**
 *
 * @author USER
 */
public class HilosJava_Video170_grupo2 {
    public static void main(String[] args) {
        JFrame frameApp = new Vista();
        frameApp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frameApp.setVisible(true);
    }
}