/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.monster.modelo;

/**
 *
 * @author Adrian Mosquera
 */
public class Banco {
    public double[] cuentas;

    public Banco() {
        this.cuentas = new double[100];
    }
}
