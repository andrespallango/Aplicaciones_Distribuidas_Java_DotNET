﻿using BIC_Standar;
using System.Data;
using System;

namespace NetCore_grupo1
{
    class Program
    {
        static void Main(string[] args)
        {
            //INSTANCIA A LA CLASE COMUN
            MiClaseComun obj = new MiClaseComun();
            //SUMA
            Console.WriteLine("LA SUMA ES: " + obj.suma(50, 50));
            //CONSULTA A LA BD
            Console.WriteLine("\nLISTADO DE CATEGORIAS\n");
            foreach (DataRow item in obj.consultaBD().Rows)
            {
                Console.WriteLine(item["ID"].ToString() + " , " + item["CATEGORIA"].ToString());
            }
            Console.ReadKey();

        }
    }
}
