﻿using System;
using System.Data;
using BIC_Standar;

namespace ProyectoNetFramework_Grupo1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //INSTANCIA A LA CLASE COMUN
            MiClaseComun obj = new MiClaseComun();
            //SUMA
            Console.WriteLine("LA SUMA ES: " + obj.suma(58, 152));
            //CONSULTA A LA BD
            Console.WriteLine("\nLISTADO DE CATEGORIAS\n");
            foreach (DataRow item in obj.consultaBD().Rows)
            {
                Console.WriteLine(item["ID"].ToString()+" , " + item["CATEGORIA"].ToString());
            }
            Console.ReadKey();

        }
    }
}
