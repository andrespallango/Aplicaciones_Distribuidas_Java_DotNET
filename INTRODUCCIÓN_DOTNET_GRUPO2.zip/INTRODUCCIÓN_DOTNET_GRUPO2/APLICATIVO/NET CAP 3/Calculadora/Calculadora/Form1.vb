﻿Imports OperacionesCSharp
'NO ES NECESARIO IMPORTAR PROYECTOS F#

Public Class Form1
    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles txtNum2.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnCalcular.Click
        Dim num1 = txtNum1.Text
        Dim num2 = txtNum2.Text
        'DESDE C#
        Dim obj As New ClaseCSharp() 'INSTANCIA A LA CLASE
        lblResulC.Text = obj.operacion1(num1, num2)

        'DESDE F#
        lblResulF.Text = FuncionesFSharp.operacion2(num1, num2)

        'DESDE OTRA SOLUCIÓN F# (.DLL)
        lblResul3.Text = ProbarFSharp.operacion2(num1, num2)

        'DESDE OTRA SOLUCIÓN F# (.EXE)
        lblResul4.Text = ProbarFSharp.operacion2(num1, num2)
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub lblOpeLibreriaFSharp_Click(sender As Object, e As EventArgs) Handles lblOpeLibreriaFSharp.Click

    End Sub
End Class
