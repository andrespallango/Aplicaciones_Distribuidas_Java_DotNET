﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.txtNum1 = New System.Windows.Forms.TextBox()
        Me.txtNum2 = New System.Windows.Forms.TextBox()
        Me.btnCalcular = New System.Windows.Forms.Button()
        Me.lblOperacionCSharp = New System.Windows.Forms.Label()
        Me.lblResulC = New System.Windows.Forms.Label()
        Me.lblResulF = New System.Windows.Forms.Label()
        Me.lblOperacionFSharp = New System.Windows.Forms.Label()
        Me.lblResul3 = New System.Windows.Forms.Label()
        Me.lblOpeLibreriaFSharp = New System.Windows.Forms.Label()
        Me.lblResul4 = New System.Windows.Forms.Label()
        Me.lblOpeAplicacionFSharp = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txtNum1
        '
        Me.txtNum1.Location = New System.Drawing.Point(143, 39)
        Me.txtNum1.Name = "txtNum1"
        Me.txtNum1.Size = New System.Drawing.Size(174, 23)
        Me.txtNum1.TabIndex = 0
        '
        'txtNum2
        '
        Me.txtNum2.Location = New System.Drawing.Point(143, 85)
        Me.txtNum2.Name = "txtNum2"
        Me.txtNum2.Size = New System.Drawing.Size(174, 23)
        Me.txtNum2.TabIndex = 1
        '
        'btnCalcular
        '
        Me.btnCalcular.Location = New System.Drawing.Point(143, 141)
        Me.btnCalcular.Name = "btnCalcular"
        Me.btnCalcular.Size = New System.Drawing.Size(174, 23)
        Me.btnCalcular.TabIndex = 2
        Me.btnCalcular.Text = "Calcular"
        Me.btnCalcular.UseVisualStyleBackColor = True
        '
        'lblOperacionCSharp
        '
        Me.lblOperacionCSharp.AutoSize = True
        Me.lblOperacionCSharp.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblOperacionCSharp.Location = New System.Drawing.Point(143, 191)
        Me.lblOperacionCSharp.Name = "lblOperacionCSharp"
        Me.lblOperacionCSharp.Size = New System.Drawing.Size(125, 15)
        Me.lblOperacionCSharp.TabIndex = 3
        Me.lblOperacionCSharp.Text = "Operaciones desde C#"
        '
        'lblResulC
        '
        Me.lblResulC.AutoSize = True
        Me.lblResulC.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblResulC.Location = New System.Drawing.Point(143, 226)
        Me.lblResulC.Name = "lblResulC"
        Me.lblResulC.Size = New System.Drawing.Size(59, 15)
        Me.lblResulC.TabIndex = 4
        Me.lblResulC.Text = "Resultado"
        '
        'lblResulF
        '
        Me.lblResulF.AutoSize = True
        Me.lblResulF.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblResulF.Location = New System.Drawing.Point(143, 329)
        Me.lblResulF.Name = "lblResulF"
        Me.lblResulF.Size = New System.Drawing.Size(59, 15)
        Me.lblResulF.TabIndex = 6
        Me.lblResulF.Text = "Resultado"
        '
        'lblOperacionFSharp
        '
        Me.lblOperacionFSharp.AutoSize = True
        Me.lblOperacionFSharp.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblOperacionFSharp.Location = New System.Drawing.Point(143, 294)
        Me.lblOperacionFSharp.Name = "lblOperacionFSharp"
        Me.lblOperacionFSharp.Size = New System.Drawing.Size(123, 15)
        Me.lblOperacionFSharp.TabIndex = 5
        Me.lblOperacionFSharp.Text = "Operaciones desde F#"
        '
        'lblResul3
        '
        Me.lblResul3.AutoSize = True
        Me.lblResul3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblResul3.Location = New System.Drawing.Point(143, 444)
        Me.lblResul3.Name = "lblResul3"
        Me.lblResul3.Size = New System.Drawing.Size(59, 15)
        Me.lblResul3.TabIndex = 8
        Me.lblResul3.Text = "Resultado"
        '
        'lblOpeLibreriaFSharp
        '
        Me.lblOpeLibreriaFSharp.AutoSize = True
        Me.lblOpeLibreriaFSharp.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblOpeLibreriaFSharp.Location = New System.Drawing.Point(143, 409)
        Me.lblOpeLibreriaFSharp.Name = "lblOpeLibreriaFSharp"
        Me.lblOpeLibreriaFSharp.Size = New System.Drawing.Size(165, 15)
        Me.lblOpeLibreriaFSharp.TabIndex = 7
        Me.lblOpeLibreriaFSharp.Text = "Operaciones desde Librería F#"
        '
        'lblResul4
        '
        Me.lblResul4.AutoSize = True
        Me.lblResul4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblResul4.Location = New System.Drawing.Point(143, 563)
        Me.lblResul4.Name = "lblResul4"
        Me.lblResul4.Size = New System.Drawing.Size(59, 15)
        Me.lblResul4.TabIndex = 10
        Me.lblResul4.Text = "Resultado"
        '
        'lblOpeAplicacionFSharp
        '
        Me.lblOpeAplicacionFSharp.AutoSize = True
        Me.lblOpeAplicacionFSharp.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblOpeAplicacionFSharp.Location = New System.Drawing.Point(143, 528)
        Me.lblOpeAplicacionFSharp.Name = "lblOpeAplicacionFSharp"
        Me.lblOpeAplicacionFSharp.Size = New System.Drawing.Size(182, 15)
        Me.lblOpeAplicacionFSharp.TabIndex = 9
        Me.lblOpeAplicacionFSharp.Text = "Operaciones desde Aplicación F#"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(473, 683)
        Me.Controls.Add(Me.lblResul4)
        Me.Controls.Add(Me.lblOpeAplicacionFSharp)
        Me.Controls.Add(Me.lblResul3)
        Me.Controls.Add(Me.lblOpeLibreriaFSharp)
        Me.Controls.Add(Me.lblResulF)
        Me.Controls.Add(Me.lblOperacionFSharp)
        Me.Controls.Add(Me.lblResulC)
        Me.Controls.Add(Me.lblOperacionCSharp)
        Me.Controls.Add(Me.btnCalcular)
        Me.Controls.Add(Me.txtNum2)
        Me.Controls.Add(Me.txtNum1)
        Me.Name = "Form1"
        Me.Text = "Calculadora - Interoperatividad entre lenguajes"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtNum1 As TextBox
    Friend WithEvents txtNum2 As TextBox
    Friend WithEvents btnCalcular As Button
    Friend WithEvents lblOperacionCSharp As Label
    Friend WithEvents lblResulC As Label
    Friend WithEvents lblResulF As Label
    Friend WithEvents lblOperacionFSharp As Label
    Friend WithEvents lblResul3 As Label
    Friend WithEvents lblOpeLibreriaFSharp As Label
    Friend WithEvents lblResul4 As Label
    Friend WithEvents lblOpeAplicacionFSharp As Label
End Class
