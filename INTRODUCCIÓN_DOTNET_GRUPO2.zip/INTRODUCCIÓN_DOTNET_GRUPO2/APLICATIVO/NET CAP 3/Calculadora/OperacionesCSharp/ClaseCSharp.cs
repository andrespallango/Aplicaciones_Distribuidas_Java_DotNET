﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OperacionesCSharp
{
    public class ClaseCSharp
    {
        public string operacion1(double num1, double num2)
        {
            return "Suma: " + Convert.ToString(num1 + num2) +
                "\nResta: " + Convert.ToString(num1 - num2);
        }
    }
}