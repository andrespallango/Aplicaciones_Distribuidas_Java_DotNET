﻿module FuncionesFSharp
open System

let operacion2 (num1:double)(num2:double)=
"Multiplicación: " + Convert.ToString(num1*num2)+
"\nDivisión: " + Convert.ToString(num1/num2)
