﻿module ProbarFSharp
open System

let suma a b = a+b
let resta a b = a-b
let multi a b = a*b
let divi a b = a/b

let operacion2 (num1:double)(num2:double)=
"Suma: " + Convert.ToString(suma num1 num2)+
"\nResta: " + Convert.ToString(resta num1 num2)+
"\nMultiplicación: " + Convert.ToString(multi num1 num2)+
"\nDivisión: " + Convert.ToString(divi num1 num2)
