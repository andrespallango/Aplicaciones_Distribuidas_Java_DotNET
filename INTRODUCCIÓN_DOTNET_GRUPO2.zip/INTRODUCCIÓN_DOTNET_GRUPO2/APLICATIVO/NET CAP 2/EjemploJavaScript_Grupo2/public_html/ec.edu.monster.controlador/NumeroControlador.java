/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.edu.monster.controlador;

import ec.edu.monster.modelo.Numero;

/**
 *
 * @author Andrés
 */
public class NumeroControlador {
     public String sumarNumeros(Numero numero1,Numero numero2)
        {
            if ((numero1.getNumero() + numero2.getNumero()) > 10)
            {
                return "La suma entre "+ numero1.getNumero()+" + "+numero2.getNumero()+" Si es mayor a 10";
            }
            return "La suma entre " + numero1.getNumero() + " + " + numero2.getNumero() + " No es mayor a 10";
        }
}
