Imports System

Module Program
    Sub Main(args As String())
        Dim num1 = 10
        Dim num2 = 1
        If ((num1 + num2) > 10) Then
            Console.WriteLine("La suma entre " & num1 & " y " & num2 & " SI es mayor a 10")
        Else
            Console.WriteLine("La suma entre " & num1 & " y " & num2 & " No es mayor a 10")
        End If
    End Sub
End Module
