﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EjemploCSharp_Grupo1.ec.edu.monster.modelo;

namespace EjemploCSharp_Grupo1.ec.edu.monster.controlador
{
    internal class NumeroControlador
    {
        public String sumarNumeros(Numero numero1,Numero numero2)
        {
            if ((numero1.getNumero() + numero2.getNumero()) > 10)
            {
                return "La suma entre "+ numero1.getNumero()+" + "+numero2.getNumero()+" Si es mayor a 10";
            }
            return "La suma entre " + numero1.getNumero() + " + " + numero2.getNumero() + " No es mayor a 10";
        }
    }
}
