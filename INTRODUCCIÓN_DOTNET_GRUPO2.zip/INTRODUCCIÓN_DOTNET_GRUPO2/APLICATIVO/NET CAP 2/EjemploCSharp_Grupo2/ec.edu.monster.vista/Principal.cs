﻿
using EjemploCSharp_Grupo1.ec.edu.monster.controlador;
using EjemploCSharp_Grupo1.ec.edu.monster.modelo;

Numero numero1 = new Numero(5);

Numero numero2 = new Numero(11);

NumeroControlador numeroControlador = new NumeroControlador();

String resultado = numeroControlador.sumarNumeros(numero1, numero2);

Console.WriteLine(resultado);