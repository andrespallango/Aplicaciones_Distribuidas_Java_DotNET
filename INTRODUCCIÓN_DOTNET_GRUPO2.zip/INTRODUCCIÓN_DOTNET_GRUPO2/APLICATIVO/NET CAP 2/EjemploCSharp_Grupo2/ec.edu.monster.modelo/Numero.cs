﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjemploCSharp_Grupo1.ec.edu.monster.modelo
{
    public class Numero
    {
        private int numero;

        public Numero(int numero)
        {
            this.numero = numero; 
        }

        public int getNumero()
        {
            return numero;
        }

        public void setNumero(int numero)
        {
            this.numero = numero;
        }
    }
}
