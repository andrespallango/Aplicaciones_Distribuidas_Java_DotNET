/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.edu.monster.vista;

import ec.edu.monster.controlador.NumeroControlador;
import ec.edu.monster.modelo.Numero;

/**
 *
 * @author andres
 */
public class Principal {

    public static void main(String[] args) {
        Numero numero1 = new Numero(5);

        Numero numero2 = new Numero(11);

        NumeroControlador numeroControlador = new NumeroControlador();

        String resultado = numeroControlador.sumarNumeros(numero1, numero2);
        
        System.out.println(resultado);
    }

}
