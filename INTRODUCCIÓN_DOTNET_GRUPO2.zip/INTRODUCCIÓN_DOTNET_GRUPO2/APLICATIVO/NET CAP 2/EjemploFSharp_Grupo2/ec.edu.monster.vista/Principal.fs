﻿open System

let num1=6.2
let num2=2.8

if((num2+num1)>10.0) then
    Console.WriteLine("La suma es mayor a 10")
else
    Console.WriteLine("la suma No es mayor a 10")
    Console.WriteLine(num1+num2)
Console.ReadKey()