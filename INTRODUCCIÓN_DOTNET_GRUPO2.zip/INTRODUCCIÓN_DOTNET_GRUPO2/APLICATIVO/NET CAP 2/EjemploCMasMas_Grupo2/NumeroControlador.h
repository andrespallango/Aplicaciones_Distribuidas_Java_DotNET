#pragma once
#include "Numero.h"
#include <string>
#include <iostream>
class NumeroControlador
{
public:

    char sumarNumeros(Numero numero1, Numero numero2);
};

char NumeroControlador::sumarNumeros(Numero numero1, Numero numero2)
{
    if ((numero1.getNumero() + numero2.getNumero()) > 10)
    {
        return '>';
    }
    return '<';
}
