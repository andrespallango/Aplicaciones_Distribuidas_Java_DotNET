#pragma once
class Numero
{
private:
    int numero1;

public :
    Numero(int numero);
    int getNumero();
    void setNumero(int numero);
};

Numero::Numero(int numero) {
    numero1 = numero;
}

int Numero::getNumero() {
    return numero1;
}

void Numero::setNumero(int numero) {
    numero1 = numero;
}

